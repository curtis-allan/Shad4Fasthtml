# SPDX-FileCopyrightText: 2024-present Curtis Allan <curtis@Curtiss-MacBook-Air.local>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
